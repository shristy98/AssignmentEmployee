﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EmpAssignment.Models
{
    public partial class AdventureWorks2017Context : DbContext
    {
        public AdventureWorks2017Context()
        {
        }

        public AdventureWorks2017Context(DbContextOptions<AdventureWorks2017Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Country> Countries { get; set; } = null!;
        public virtual DbSet<Department> Departments { get; set; } = null!;
        public virtual DbSet<Division> Divisions { get; set; } = null!;
        public virtual DbSet<Emp> Emps { get; set; } = null!;
        public virtual DbSet<EmploymentLocation> EmploymentLocations { get; set; } = null!;
        public virtual DbSet<EmploymentStatus> EmploymentStatuses { get; set; } = null!;
        public virtual DbSet<Location> Locations { get; set; } = null!;
        public virtual DbSet<Zone> Zones { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("server=192.168.1.230;user=trainee2022;password=trainee@2022;database=AdventureWorks2017");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Country>(entity =>
            {
                entity.HasKey(e => e.Pincode)
                    .HasName("PK__country__54608448E97A7485");

                entity.ToTable("country");

                entity.Property(e => e.Pincode).ValueGeneratedNever();

                entity.Property(e => e.District)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.StateName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(e => e.DeptId)
                    .HasName("PK__DEPARTME__512A59ACBA1B3726");

                entity.ToTable("DEPARTMENT", "Shris");

                entity.Property(e => e.DeptId).HasColumnName("DEPT_ID");

                entity.Property(e => e.DeptName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("DEPT_NAME");
            });

            modelBuilder.Entity<Division>(entity =>
            {
                entity.ToTable("DIVISION", "Shris");

                entity.Property(e => e.DivisionId).HasColumnName("DIVISION_ID");

                entity.Property(e => e.DivisionName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("DIVISION_NAME");
            });

            modelBuilder.Entity<Emp>(entity =>
            {
                entity.ToTable("emp", "Shris");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Address1)
                    .HasMaxLength(400)
                    .IsUnicode(false)
                    .HasColumnName("ADDRESS1");

                entity.Property(e => e.Address2)
                    .HasMaxLength(400)
                    .IsUnicode(false)
                    .HasColumnName("ADDRESS2");

                entity.Property(e => e.City)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CITY");

                entity.Property(e => e.ContactNo).HasColumnName("CONTACT_NO");

                entity.Property(e => e.ContactPhone).HasColumnName("CONTACT_PHONE");

                entity.Property(e => e.Country)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("COUNTRY")
                    .HasDefaultValueSql("('INDIA')");

                entity.Property(e => e.Department)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("DEPARTMENT");

                entity.Property(e => e.Division)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("DIVISION");

                entity.Property(e => e.DominantHand)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("DOMINANT_HAND")
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.Empenddate)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPENDDATE");

                entity.Property(e => e.EmployeeNo)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_NO");

                entity.Property(e => e.EmployeeWorkShift)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_WORK_SHIFT");

                entity.Property(e => e.EmploymentStatus)
                    .HasColumnName("EMPLOYMENT_STATUS")
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.Empstartdate)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPSTARTDATE");

                entity.Property(e => e.Empstatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPSTATUS");

                entity.Property(e => e.Firstname)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FIRSTNAME");

                entity.Property(e => e.Gender)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("GENDER");

                entity.Property(e => e.Height)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("HEIGHT");

                entity.Property(e => e.Homephone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("HOMEPHONE");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("LASTNAME");

                entity.Property(e => e.Location)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("LOCATION");

                entity.Property(e => e.MartialStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("MARTIAL_STATUS")
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.Middlename)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("MIDDLENAME");

                entity.Property(e => e.OfDependents).HasColumnName("OF_DEPENDENTS");

                entity.Property(e => e.SsnSin)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("SSN_SIN");

                entity.Property(e => e.StateProvince)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("STATE_PROVINCE");

                entity.Property(e => e.Workphone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("WORKPHONE");

                entity.Property(e => e.ZipPostal)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ZIP_POSTAL");

                entity.Property(e => e.Zone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ZONE");
            });

            modelBuilder.Entity<EmploymentLocation>(entity =>
            {
                entity.HasKey(e => e.EmploymentId)
                    .HasName("PK__EMPLOYME__BF8486481E08F3D4");

                entity.ToTable("EMPLOYMENT_LOCATION", "Shris");

                entity.Property(e => e.EmploymentId).HasColumnName("EMPLOYMENT_ID");

                entity.Property(e => e.EmploymentName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYMENT_NAME");
            });

            modelBuilder.Entity<EmploymentStatus>(entity =>
            {
                entity.HasKey(e => e.StatusId)
                    .HasName("PK__EMPLOYME__D8827E710ADDD521");

                entity.ToTable("EMPLOYMENT_STATUS", "Shris");

                entity.Property(e => e.StatusId).HasColumnName("STATUS_ID");

                entity.Property(e => e.StatusName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("STATUS_NAME");
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("LOCATION", "Shris");

                entity.Property(e => e.LocationId).HasColumnName("LOCATION_ID");

                entity.Property(e => e.LocationName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("LOCATION_NAME");
            });

            modelBuilder.Entity<Zone>(entity =>
            {
                entity.ToTable("ZONE", "Shris");

                entity.Property(e => e.ZoneId).HasColumnName("ZONE_ID");

                entity.Property(e => e.ZoneName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("ZONE_NAME");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
