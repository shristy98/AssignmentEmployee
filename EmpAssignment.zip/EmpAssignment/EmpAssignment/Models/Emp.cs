﻿using System;
using System.Collections.Generic;

namespace EmpAssignment.Models
{
    public partial class Emp
    {
        public int Id { get; set; }
        public string Firstname { get; set; } = null!;
        public string? Middlename { get; set; }
        public string Lastname { get; set; } = null!;
        public string Gender { get; set; } = null!;
        public string Height { get; set; } = null!;
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Country { get; set; }
        public string StateProvince { get; set; } = null!;
        public string City { get; set; } = null!;
        public string? ZipPostal { get; set; }
        public string? Homephone { get; set; }
        public string? Workphone { get; set; }
        public string? EmployeeNo { get; set; }
        public string? EmployeeWorkShift { get; set; }
        public string? Division { get; set; }
        public string? Location { get; set; }
        public string? Department { get; set; }
        public string? Zone { get; set; }
        public string? Empstatus { get; set; }
        public string? Empstartdate { get; set; }
        public string? Empenddate { get; set; }
        public string? SsnSin { get; set; }
        public string? MartialStatus { get; set; }
        public string? DominantHand { get; set; }
        public int? OfDependents { get; set; }
        public long? ContactNo { get; set; }
        public long? ContactPhone { get; set; }
        public int? EmploymentStatus { get; set; }
    }
}
