﻿using System;
using System.Collections.Generic;

namespace EmpAssignment.Models
{
    public partial class Country
    {
        public int Pincode { get; set; }
        public string? District { get; set; }
        public string StateName { get; set; } = null!;
    }
}
