﻿using System;
using System.Collections.Generic;

namespace EmpAssignment.Models
{
    public partial class Zone
    {
        public int ZoneId { get; set; }
        public string ZoneName { get; set; } = null!;
    }
}
