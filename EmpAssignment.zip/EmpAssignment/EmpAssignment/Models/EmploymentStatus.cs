﻿using System;
using System.Collections.Generic;

namespace EmpAssignment.Models
{
    public partial class EmploymentStatus
    {
        public int StatusId { get; set; }
        public string StatusName { get; set; } = null!;
    }
}
