﻿using System;
using System.Collections.Generic;

namespace EmpAssignment.Models
{
    public partial class EmploymentLocation
    {
        public int EmploymentId { get; set; }
        public string EmploymentName { get; set; } = null!;
    }
}
