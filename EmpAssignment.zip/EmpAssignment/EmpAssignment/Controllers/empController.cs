﻿using EmpAssignment.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace EmpAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class empController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public empController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"select * from shris.emp";

            DataTable data = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader MyReader;
            using (SqlConnection MyPlace = new SqlConnection(sqlDataSource))
            {
                MyPlace.Open();
                using (SqlCommand MyCommand = new SqlCommand(query, MyPlace))
                {
                    MyReader = MyCommand.ExecuteReader();
                    data.Load(MyReader);
                    MyReader.Close();
                    MyPlace.Close();

                }
            }
            return new JsonResult(data);


        }
        [HttpPost]

        public JsonResult Post([FromBody]Emp emp)
        {
            string query = @"insert into shris.emp(FIRSTNAME,MIDDLENAME,LASTNAME,GENDER,HEIGHT,ADDRESS1,ADDRESS2,COUNTRY,STATE_PROVINCE,
CITY,ZIP_POSTAL,HOMEPHONE,WORKPHONE,EMPLOYEE_NO,EMPLOYEE_WORK_SHIFT,DIVISION,LOCATION,DEPARTMENT,ZONE,EMPSTATUS,EMPSTARTDATE,
EMPENDDATE,SSN_SIN,MARTIAL_STATUS,DOMINANT_HAND,OF_DEPENDENTS,CONTACT_NO,CONTACT_PHONE,EMPLOYMENT_STATUS)
values(@FIRSTNAME, @MIDDLENAME,@LASTNAME,@GENDER,@HEIGHT,@ADDRESS1,@ADDRESS2,@COUNTRY,@STATE_PROVINCE,
@CITY,@ZIP_POSTAL,@HOMEPHONE,@WORKPHONE,@EMPLOYEE_NO,@EMPLOYEE_WORK_SHIFT,@DIVISION,@LOCATION,@DEPARTMENT,@ZONE,@EMPSTATUS,@EMPSTARTDATE,
@EMPENDDATE,@SSN_SIN,@MARTIAL_STATUS,@DOMINANT_HAND,@OF_DEPENDENTS,@CONTACT_NO,@CONTACT_PHONE,@EMPLOYMENTSTATUS)";



            DataTable data = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader MyReader;
            using (SqlConnection MyPlace = new SqlConnection(sqlDataSource))
            {
                MyPlace.Open();
                using (SqlCommand MyCommand = new SqlCommand(query, MyPlace))
                {

                  //  MyCommand.Parameters.AddWithValue("@ID", emp.Id);
                    MyCommand.Parameters.AddWithValue("@FIRSTNAME", emp.Firstname);
                    MyCommand.Parameters.AddWithValue("@MIDDLENAME", emp.Middlename);
                    MyCommand.Parameters.AddWithValue("@LASTNAME", emp.Lastname);
                    MyCommand.Parameters.AddWithValue("@GENDER", emp.Gender);
                    MyCommand.Parameters.AddWithValue("@HEIGHT", emp.Height);
                    MyCommand.Parameters.AddWithValue("@ADDRESS1", emp.Address1);
                    MyCommand.Parameters.AddWithValue("@ADDRESS2", emp.Address2);
                    MyCommand.Parameters.AddWithValue("@COUNTRY", emp.Country);
                    MyCommand.Parameters.AddWithValue("@STATE_PROVINCE", emp.StateProvince);
                    MyCommand.Parameters.AddWithValue("@CITY", emp.City);
                    MyCommand.Parameters.AddWithValue("@ZIP_POSTAL", emp.ZipPostal);
                    MyCommand.Parameters.AddWithValue("@HOMEPHONE", emp.Homephone);
                    MyCommand.Parameters.AddWithValue("@WORKPHONE", emp.Workphone);
                    MyCommand.Parameters.AddWithValue("@EMPLOYEE_NO", emp.EmployeeNo);
                    MyCommand.Parameters.AddWithValue("@EMPLOYEE_WORK_SHIFT", emp.EmployeeWorkShift);
                    MyCommand.Parameters.AddWithValue("@DIVISION", emp.Division);
                    MyCommand.Parameters.AddWithValue("@LOCATION", emp.Location);
                    MyCommand.Parameters.AddWithValue("@DEPARTMENT", emp.Department);
                    MyCommand.Parameters.AddWithValue("@ZONE", emp.Zone);
                    MyCommand.Parameters.AddWithValue("@EMPSTATUS", emp.Empstatus);
                    MyCommand.Parameters.AddWithValue("@EMPSTARTDATE", emp.Empstartdate);
                    MyCommand.Parameters.AddWithValue("@EMPENDDATE", emp.Empenddate);
                    MyCommand.Parameters.AddWithValue("@SSN_SIN", emp.SsnSin);
                    MyCommand.Parameters.AddWithValue("@MARTIAL_STATUS", emp.MartialStatus);
                    MyCommand.Parameters.AddWithValue("@DOMINANT_HAND", emp.DominantHand);
                    MyCommand.Parameters.AddWithValue("@OF_DEPENDENTS", emp.OfDependents);
                    MyCommand.Parameters.AddWithValue("@CONTACT_NO", emp.ContactNo);
                    MyCommand.Parameters.AddWithValue("@CONTACT_PHONE", emp.ContactPhone);
                    MyCommand.Parameters.AddWithValue("@EMPLOYMENTSTATUS", emp.EmploymentStatus);
                    MyReader = MyCommand.ExecuteReader();
                    data.Load(MyReader);
                    MyReader.Close();
                    MyPlace.Close();

                }
            }
            return new JsonResult("Add Successfully");
        }
        //put..................................................................................................



        [HttpPut]

        public JsonResult Put(Emp emp
            )
        {
            string query = @" update Shris.emp
                              set ID= @ID
                              where ID=@ID
                                     ";

            DataTable data = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader MyReader;
            using (SqlConnection MyPlace = new SqlConnection(sqlDataSource))
            {
                MyPlace.Open();
                using (SqlCommand MyCommand = new SqlCommand(query, MyPlace))
                {


                    //  MyCommand.Parameters.AddWithValue("@ID", emp.Id);
                    MyCommand.Parameters.AddWithValue("@FIRSTNAME", emp.Firstname);
                    MyCommand.Parameters.AddWithValue("@MIDDLENAME", emp.Middlename);
                    MyCommand.Parameters.AddWithValue("@LASTNAME", emp.Lastname);
                    MyCommand.Parameters.AddWithValue("@GENDER", emp.Gender);
                    MyCommand.Parameters.AddWithValue("@HEIGHT", emp.Height);
                    MyCommand.Parameters.AddWithValue("@ADDRESS1", emp.Address1);
                    MyCommand.Parameters.AddWithValue("@ADDRESS2", emp.Address2);
                    MyCommand.Parameters.AddWithValue("@COUNTRY", emp.Country);
                    MyCommand.Parameters.AddWithValue("@STATE_PROVINCE", emp.StateProvince);
                    MyCommand.Parameters.AddWithValue("@CITY", emp.City);
                    MyCommand.Parameters.AddWithValue("@ZIP_POSTAL", emp.ZipPostal);
                    MyCommand.Parameters.AddWithValue("@HOMEPHONE", emp.Homephone);
                    MyCommand.Parameters.AddWithValue("@WORKPHONE", emp.Workphone);
                    MyCommand.Parameters.AddWithValue("@EMPLOYEE_NO", emp.EmployeeNo);
                    MyCommand.Parameters.AddWithValue("@EMPLOYEE_WORK_SHIFT", emp.EmployeeWorkShift);
                    MyCommand.Parameters.AddWithValue("@DIVISION", emp.Division);
                    MyCommand.Parameters.AddWithValue("@LOCATION", emp.Location);
                    MyCommand.Parameters.AddWithValue("@DEPARTMENT", emp.Department);
                    MyCommand.Parameters.AddWithValue("@ZONE", emp.Zone);
                    MyCommand.Parameters.AddWithValue("@EMPSTATUS", emp.Empstatus);
                    MyCommand.Parameters.AddWithValue("@EMPSTARTDATE", emp.Empstartdate);
                    MyCommand.Parameters.AddWithValue("@EMPENDDATE", emp.Empenddate);
                    MyCommand.Parameters.AddWithValue("@SSN_SIN", emp.SsnSin);
                    MyCommand.Parameters.AddWithValue("@MARTIAL_STATUS", emp.MartialStatus);
                    MyCommand.Parameters.AddWithValue("@DOMINANT_HAND", emp.DominantHand);
                    MyCommand.Parameters.AddWithValue("@OF_DEPENDENTS", emp.OfDependents);
                    MyCommand.Parameters.AddWithValue("@CONTACT_NO", emp.ContactNo);
                    MyCommand.Parameters.AddWithValue("@CONTACT_PHONE", emp.ContactPhone);
                    MyCommand.Parameters.AddWithValue("@EMPLOYMENTSTATUS", emp.EmploymentStatus);
                    MyReader = MyCommand.ExecuteReader();
                    data.Load(MyReader);
                    MyReader.Close();
                    MyPlace.Close();

                }
            }
            return new JsonResult("Update successfully");

        }

        //Delete...........................................................................



        [HttpDelete("{ID}")]

        public JsonResult Delete(int ID)
        {
            string query = @" delete from shris.emp

                              where ID=@ID
                                     ";

            DataTable data = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader MyReader;
            using (SqlConnection MyPlace = new SqlConnection(sqlDataSource))
            {
                MyPlace.Open();
                using (SqlCommand MyCommand = new SqlCommand(query, MyPlace))
                {
                    MyCommand.Parameters.AddWithValue("@ID", ID);
                    MyReader = MyCommand.ExecuteReader();
                    data.Load(MyReader);
                    MyReader.Close();
                    MyPlace.Close();

                }
            }
            return new JsonResult("Delete Successfully");

        }
    }

}
