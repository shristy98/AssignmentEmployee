import React, { Component } from 'react'
import Service from './Service'

export default class user extends Component {

    constructor(props){
        super(props)
        this.state={
            user:[]
        }
    }

componentDidMount(){
    Service.getUser().then((res)=>{
        this.setState({user:res.data})
    });

}

  render() {
    return (
      <div>
        <h1>Country</h1>
        <table className='table table-sprit'>
            <thead>
                <tr>
                   
                    <td>pincode</td>
                    <td>district</td>
                    <td>stateName</td>
                   
                </tr>
            </thead>
            <tbody>
                {
                    this.state.user.map(
                        user =>
                        <tr key={user.Id}>
                            <td>{user.pincode}</td>
                            <td>{user.district}</td>
                            <td>{user.stateName}</td>

                        </tr>
                        
                    )
                }
            </tbody>

        </table>
      </div>
    )
  }
}