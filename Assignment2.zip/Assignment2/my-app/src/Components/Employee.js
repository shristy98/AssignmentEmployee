import React from 'react'
import '../Components/Employee.css'

export default function Employee() {
  return (
  <div class='abc'>
  <span>
  <button type="submit" className="button1">Add</button>
  </span>
  

        <span>
          <button type="submit" className="button">Modify</button>
        </span>
        <span>
          <button type="submit" className="button">Save</button>
        </span>
        <span>
          <button type="submit" className="button">Cancel</button>
        </span>
        <span>
          <button type="submit" className="button">Remove</button>
        </span>
        
  
  
 

    <h2>General Information</h2>
    <form>

      <div>
        <div class="row">
        <div class="input-group">
         <div class="col-5 bg-info" id='First'>
         <label>First:</label>
             </div>
             <div class="col-2 bg-info" id='Middle'>
             <label>Middle:</label>
             </div>
             <div class="col-5 bg-info" id='Last'>
             <label>Last:</label>
             </div>
         </div>            
         
     
     <div class="row">
     
        <div class="col-md-5 h-50">
          <input type="text" /><br />
        </div>
          <div class="col-md-2 h-50">
            <input type="text" /><br />
          </div>
          <div class="col-md-5 h-50">
            <input type="text" /><br />
          </div>
        </div>
      </div>
      
    
      

      <div class="row">
        <div class="col-md-2 bg-info"  id='gender'>
          <label>Gender:</label>

        </div>
        <div class="col-md-10 w-50">
          <input type="radio" value="Male" name="gender" />Male
          <input type="radio" value="FEMALE" name="gender" /> Female
        </div>

      </div>
      <div class="row">
        <div class="col-md-2 bg-info"  id='Height'>
          <label>Height:</label>
        </div>
        <div class="col-md-10 w-50">
          <input type="text" /><br />            
        </div>
      </div>
      <div class="row">
        <div class="col-md-2 bg-info" id='add'>
          <label>Address1:</label>
          <label>Address2:</label>
        </div>
        <div class="col-md-10 w-50" id='input'>
          <input type="text" /><br />
          <input type="text" /><br />
        </div>
      </div>
      
      <div class="row" style={{width:"1500px"}}>
      <div class=" bg-info"  id='Country'style={{width:"200px"}}>
          <label>Country:</label>
        </div>
        <div  style={{width:"325px"}}>
          <select class="form-select" aria-label="Default select example">
            <option value="1"></option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>

        <div class="bg-info " id='city'  >
        <label>City:</label>            
      </div>
      <div id='in' style={{width:"405px"}}>
        <input type="text" /><br />  
    </div>

    </div>

      <div class="row"  style={{width:"1500px"}}>
      <div class=" bg-info"  id='Province' style={{width:"200px"}}>
          <label>State/Province:</label>
        </div>
        <div style={{width:"325px"}}>
          <select class="form-select" aria-label="Default select example">
            <option value="1"></option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
        <div class="bg-info " id='ZipPostal' style={{width:"150px"}}>
        <label>Zip Postal:</label>            
      </div>
      <div id='in' style={{width:"405Px"}}>
      
        <input type="text" /><br />  
    </div>

    </div>
    <div class="row" style={{width:"1800px"}}>
      <div class="col-md-2 bg-info"  id='Postal' style={{width:"200px"}}>
          <label>Home Phone:</label>
        </div>
        <div  style={{width:"650Px"}}>
          <input type="text" /><br />
        </div>
        <div class="bg-info " id='WorkPhone' style={{width:"150px"}}>
        <label>Work Phone:</label>            
      </div>
      <div id='in' style={{width:"405Px"}}>
      
        <input type="text" /><br />  
    </div>
      </div>

      <div class="row">
        <div class="col-md-2 bg-info"  id='Email'>
          <label>Email:</label>
        </div>
        <div class="col-md-10 w-50">
          <input type="text" /><br />            
        </div>
      </div> 
      
      <h2>Employee Information</h2>

      <div class="row">
        <div class="col-md-2 bg-info"  id='employee'>
          <label>Employee Number:</label>
        </div>
        <div class="col-md-10 w-50">
          <input type="text" /><br />
        </div>
      </div>

      <div class="row">
        <div class="col-md-2 bg-info" id='Employee'>
          <label>Employee work shift:</label>
        </div>
        <div class="col-md-2 w-20" id='input1'>
          <input type="text" />
          <label>Hrs/day:</label>            
          <input type="text" />
          <label>Hrs/Week:</label>            
        </div>
      </div>

  
      <div class=" row pt-2">
        <label for="" class="col-sm-2 col-form-label bg-info">Employement Location:</label>
        <div class="col-sm-10 w-25">
        <label>Zone:</label>
        </div>
        <div class="col-sm-10 w-25">
          <select class="form-select form-select-sm" aria-label=".form-select-sm example" >
            <option selected>Please Select</option>
            
          </select>
         
        </div>
        </div>
        <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info"></label>
        <div class="col-sm-5 w-25">
        <label>Location:</label>
        </div>
        <div class="col-sm-10 w-25">
          <select class="form-select form-select-sm" aria-label=".form-select-sm example" >
            <option selected>Please Select</option>
            
          </select>
         
        </div>
        </div>
        <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info"></label>
        <div class="col-sm-5 w-25">
        <label>Department:</label>
        </div>
        <div class="col-sm-10 w-25">
          <select class="form-select form-select-sm" aria-label=".form-select-sm example" >
            <option selected>Please Select</option>
            
          </select>
         
        </div>
        </div>

        <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info"></label>
        <div class="col-sm-10 w-25">
       <label>shristy</label>
        </div>
        <div class="col-sm-10 w-25">
          <select class="form-select form-select-sm" aria-label=".form-select-sm example" >
            <option selected>Please Select</option>
            
          </select>
         
        </div>
        </div>
    
        <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info mt-2">Employee Status:</label>
        <div class="col-sm-10 w-25">
        <select class="form-select" aria-label="Default select example">
            <option selected>please select</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
        </div>
      
      </div>

      
      <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info mt-2">Martial Status:</label>
        <div class="col-sm-10 w-25">
        <input type="radio" value="Male" name="gender" />N/A
          <input type="radio" value="FEMALE" name="gender" /> Single
          <input type="radio" value="FEMALE" name="gender" /> Married
        </div>
        </div>

        <div class=" row ">
        <label for="" class="col-sm-2 col-form-label bg-info mt-2">Dominant Hand</label>
        <div class="col-sm-10 w-25">
        <input type="radio" value="Male" name="gender" />N/A
          <input type="radio" value="FEMALE" name="gender" /> Left
          <input type="radio" value="FEMALE" name="gender" /> Right
        </div>
        </div>
      
    </form>
</div>

    
  
)
}

