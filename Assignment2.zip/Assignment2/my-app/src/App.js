import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route,Routes} from 'react-router-dom';
import Employee from './Components/Employee';
import User from './Components/User';

// function App() {
//   return (
//     <div className="App">
//       <Router>
//         <Routes>
//             <Route exact path = "/" element = {<Employee/>}></Route>
//         </Routes>
//       </Router>
//     </div>
//   );
// }
function App() {
  return (
    <div className="App">
    <Employee />
    <User/>
    </div>
  );
}

export default App;

